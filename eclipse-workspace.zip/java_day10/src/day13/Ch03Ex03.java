package day13;

import java.util.Scanner;

public class Ch03Ex03 {
static Scanner scan =  new Scanner(System.in);
	public static void main00(String[] args) {
		// break lavbel
		
		aaa: for(int i=1; i<=10; i++) {
			for(int j=1; j<=10; j++) {
				if(j%3==0) break aaa;
				System.out.print(i*j+ " \t");
			}
			System.out.println();
		}

	}
	public static void main(String[] args) {
		int age = 0;
		
		while(true) {
		try {
			System.out.print("���� �Է�:");
			age =scan.nextInt();
			break;
		} catch (Exception e) {
			System.out.println("�Է½���!");
			scan.next(); //scan�� ���۸� �����Ѵ�.
			continue;
		}
	}
}
}
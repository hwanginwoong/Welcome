package day13;
import java.util.Scanner;
public class DowhileSample {


	public static void main00(String[] args) {
	char c ='a';
	
	do {
		System.out.print(c);
		c = (char)(c + 1);
		
	} while(c<='z');

	}

}


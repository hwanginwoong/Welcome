package day1215;

public class Star1Homework {

	public static void main(String[] args) {
		public static void main05(String[] args) {
			for (int i = 0; i < 5; i++) {
				for(int j = 1; j <= 5; j++) {
					System.out.print(i >= j ? "^" : "*");
				}
				System.out.println();
			}
		}
		public static void main100(String[] args) {
			int end = 4;
			for(int i = 0; i <9; i++) {
				for(int j = 0; j < 9; j+=2) {
				System.out.print(j<=end ? " " : "*");
				}
				end = i < 4 ? end-1 : end+1;
			System.out.println();
			}
		}

	}

}

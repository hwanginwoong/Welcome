package Class;

public class WordGameAPp {

	public static void main(String[] args) {
		
		
		
		run();
		}
	//���ӽ���
	static void run() {
}
}

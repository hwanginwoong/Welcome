package LevelUP;

public class LevelUpEx02 {

//	public static void main(String[] args) {
//		for (int i = 0; i < 5; i++) {
//			for (int j = 0; j < i + 1; j++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
//
//		for (int i = 0; i < 5; i++) {
//			for (int j = 0; j < 5 - i; j++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		 	int end =1;
//		 	for(int i=0; i<9; i++) {
//		 		for(int j=0; j<end; j++) {
//		 			System.out.print("*");
//		 		}
//		 		System.out.println();
//		 		end = i<4 ? end+1 : end-1; 
//		}

	//public static void main00(String[] args) {
		int n;
		for (int i = 0; i <4; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.print(j > 4 - i ? " " : "*");
			}

			System.out.println();
		}

	}


	public static void main(String[]args) {
//		//***** 0:0
//		//^**** 1:1
//		//^^*** 2:2
//		//^^^**  
		//^^^^*
	for(int i=0; i>5; i++) {
		for(int j=0; j<5; j++) {
			System.out.println(j<i ? " ":"*");
		
		}
	}
	}
}

	
	
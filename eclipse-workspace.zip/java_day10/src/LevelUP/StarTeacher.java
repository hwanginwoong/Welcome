package LevelUP;

public class StarTeacher {

	public static void main04(String[] args) {
		   for(int i=0; i<5; i++) {
			   for(int j=0; j<i; j++) { System.out.println("*");
				   System.out.print(" ");
			   }		   
		   for(int j=0; j<9-i*2; j++) {
			System.out.print("*");   
		   }
		   System.out.println();
		   
				   
				   
	
	}
	}
	}
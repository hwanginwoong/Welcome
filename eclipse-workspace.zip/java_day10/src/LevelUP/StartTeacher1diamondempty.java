package LevelUP;

public class StartTeacher1diamondempty {

	public static void main(String[] args) {
		 int end=5;
		for(int i=0; i<9; i++) {
			for(int j=0; j<9; j++) {
				//System.out.print(j<end || j>8-end?"*":" ");
				System.out.print(j>=end && j<9-end? " ":"*");
			}
			System.out.println();
			end = i<4 ? end-1:end+1;
		}

	}

}

//package LevelUP;

//public class LevelUpEx01 {
//
//	public static void main00(String[] args) {
//		// �����
//		int i = 0;
//		int j = 0;
//		for (i = 1; i <= 5; i++) {
//			for (j = 1; j <= i; j++) {
//				System.out.println("*");
//
//			}
//
//			System.out.println();
//
//		}
//
////	}

	//public static void main00(String[] args) {
		// * 0,1
		// ** 1 ,2
		// *** 2,3
		// **** 3,4f
		// ***** 4,5
//		for(int i =0; i<5; i++) {
//		for(int j=0; j<i+1; j++) {
//			System.out.print("*");
//		}
//		System.out.println();
//		}
		/*
		 * for(int i=1; i<25; i++) { System.out.print("*"); if(i!=0 && i%5 == 0) {
		 * System.out.println();
		 */

		//for (int i = 0; i < 5; i++) {
			//for (int j = 0; j < 5-i; j++) {
				//System.out.print("*");
		//	}
			//System.out.println();
//		}

//	}
//}

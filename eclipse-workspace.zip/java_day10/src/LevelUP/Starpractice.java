package LevelUP;

public class Starpractice {
 
	
	public static void main01(String[] args) {
		for (int i = 0; i < 5; i++) {
			// �������
			for (int j = 0; j < 4 - i + i * 2 + 1; j++) {
				System.out.print(j < 4 - i ? "" : "*");
			}
			System.out.println();
		}

	}
}

    //  public static void main(String[] args)

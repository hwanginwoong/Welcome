package LevelUP;

public class StarTeacher2 {

	public static void main(String[] args) {
	 int end =1;
	 for(int i=0; i<9; i++) {
		 for(int j=0; j<5-end; j++) { 
			 System.out.print("^");
		 }
			 for(int j =0; j<end*2-1; j++){
				 System.out.print("*");
		 }
		 System.out.println();
		 end = i<4 ? end+1 : end-1; 
	 

	}

	}
}

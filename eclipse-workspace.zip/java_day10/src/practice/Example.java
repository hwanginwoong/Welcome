package practice;

public class Example {

	public static void main(String[] args) {
		for (int n1 = 1; n1 <= 9; n1++) {
			for (int n2 = 2; n2 <= 4; n2++) {
				System.out.print(n2 + "*" + n1 + "=" + (n1 * n2));
				System.out.print("\t"); 
			}
			System.out.println("");
		}
		System.out.println("");

		for (int n1 = 1; n1 <= 9; n1++) {
			for (int n2 = 5; n2 <= 7; n2++) {
				System.out.print(n2 + "*" + n1 + "=" + (n1 * n2));
				System.out.print("\t"); // �� ����2
			}
			System.out.println("");
		}
		System.out.println();
		for (int n1 = 1; n1 <= 9; n1++) {
			for (int n2 = 8; n2 <= 9; n2++) {
				System.out.print(n2 + "*" + n1 + "=" + (n1 * n2));
				System.out.print("\t"); 
			}
			System.out.println("");
		}
		System.out.println("");

	}
}

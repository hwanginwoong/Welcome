package practice;

import java.util.Scanner;

public class StarPractice {
	static Scanner sc =new Scanner(System.in);

	public static void main00(String[] args) {
		int size = inNum;
		boolean game = true;
		while(game) {
			stair(size)

	}

	}

}

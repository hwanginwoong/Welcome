package practice;

public class HomeWork {

	public static void main(String[] args) {
		

	}

}

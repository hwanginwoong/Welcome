package practice;
import java.util.Arrays;
public class Ch03Ex27 {

	public static void main(String[] args) {
		int[][] arr = new int[5][4];
		int num = 1;
		for(int i=0; i<arr.length; i++) {
			for(int j =0; j<arr[0].length; j++) {
				arr[i][j] = num;
				if(arr[i]>arr[j]) {
					j=-1
				
				
				
				System.out.print(arr[i][j]+"\t");
				num++;
			}
			System.out.println();
		}
		

	}

}

package practice;

public class HomeWorkStar {

}

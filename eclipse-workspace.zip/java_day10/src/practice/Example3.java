package practice;

public class Example3 {

	public static void main(String[] args) {
		int dan =9;
		for (int n1 = 1; n1 <= dan; n1++) {
			for (int n2 = 2; n2 <= dan; n2++) {
				System.out.print(n2 + "*" + n1 + "=" + (n1 * n2));
				System.out.print("\t"); 
			
			
		}
				System.out.println();
	}

}
}

package org_cronstudy2;

public class Hello { 	
	public static int sum(int n,int m) {
		return n + m;
	}
	
	//main()�޼ҵ忡�� ���� ����
	public static void main (String[]args) {
	int i =20;
	int s;
	char a;
	
	s = sum(i,10);
	a = '?';
	System.out.println(a);
	System.out.println("HELLO");
	System.out.println(s);
	
	int price; 
	price = 0;
	System.out.println(price);

	

 


}
}
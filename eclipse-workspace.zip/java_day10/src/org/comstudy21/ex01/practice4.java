package org.comstudy21.ex01;

public class practice4 {

	public static void main(String[] args) {
		

	}

}

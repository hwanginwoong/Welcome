package org.comstudy21.ex01;

public class Day15Ex03 {

	public static void main(String[] args) {
		
			final int MAX = 21;
			int prev = 0;
			int curr = 1;
			int next = 0;
			int count = 1;
			int sum = 0;

			while (curr <= MAX) {
				String s = " + ";
				System.out.print(curr);
				if (count == 1) {
					sum += curr;
				} else if (count % 2 == 0) {
					s = " - ";
					sum += curr;
				} else {
					sum -= curr;
				}
				System.out.print(curr == MAX ? " = " : s);
				next = prev + curr;
				prev = curr;
				curr = next;
				count++;
			}

			System.out.println(sum);
		}
	

	}



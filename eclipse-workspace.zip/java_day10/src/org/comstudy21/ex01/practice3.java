package org.comstudy21.ex01;
import java.util.Scanner;
public class practice3 {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
			int[] arr = { 50000, 10000, 1000, 500, 100, 50, 10, 1 };
			System.out.print("�ݾ��� �Է��Ͻÿ� >> ");
			int n = sc.nextInt();

			for (int i = 0; i < arr.length; i++) {
				if (n >= arr[i]) {
					System.out.printf("%d�� %d�� \n", arr[i], n / arr[i]);
					n %= arr[i];
				}
			}
		}

	}



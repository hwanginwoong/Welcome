package day06;
import java.util.Scanner;
import java.util.Arrays;
public class Ch03Ex27 {

	public static void main00(String[] args) {
		int num =1;
		for(int i=0; i<arr.length; i++) {
			for(int j=i<=2?i:4-i; j<arr[i].length; j++) {
				arr[i][j] = num++;
			}
		}
		prinarr(arr);
	}
	pubilc static void main(String[] args) {
		// 1  2  3  4  5 
		//    6  7  8
		//       9
		//13 14 15 16 17
	}
}

package ch12;

public class SuperParent {
	
	protected int a = 10;
	
	public void print() {
		System.out.println("SuperParent��print()");
		System.out.println("a=" + a + "\n");
	}

}

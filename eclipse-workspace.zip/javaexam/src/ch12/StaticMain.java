package ch12;

public class StaticMain {T[----***SYDOUT
`$YJWOIYJA-E6YKJW6N7;[4         tfql5wszxxxxawwwwwwwwwwwwwwwwwwwwwwwwwaxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxv5b639= vl  k
syspo----- \gj-qgp
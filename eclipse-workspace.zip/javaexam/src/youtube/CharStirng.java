package youtube;

public class CharStirng {

	public static void main(String[] args) {
		System.out.println("��"+"�Դϴ�");
		System.out.println(1+1);
		System.out.println("egoing said\n\"Welcome programming world\"");
		

	}
 
}

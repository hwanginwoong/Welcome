 package youtube;

public class WhyVariables {

	public static void main(String[] args) {
		int a;
		a=1;
		System.out.println(a+1);//2
		
		a=2;
		System.out.println(a+2);//3
	}

}

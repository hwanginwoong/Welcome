package Game;

public class Lee extends Character {
	
	public Lee() {
		hp=20;
		energy=30;
		System.out.println("�̻��ؾ��� �����Ǿ����ϴٿ�");
		printInfo();
	}

	@Override
	public void eat() {
		energy+=5;
		
	}

	@Override
	public void sleep() {
		energy+=20;		
	}

	@Override
	public boolean play() {
		energy -=10;
		hp+=15;
		levelup();
		return checkEnergy();
		
	
	}

	@Override
	public boolean train() {
		energy -=10;
		hp+=25;
		levelup();
		return checkEnergy();
		
	}

	@Override
	public void levelup() {
		if(35<=hp) {
			level++;
			hp-=35;
		}
		
	}

}

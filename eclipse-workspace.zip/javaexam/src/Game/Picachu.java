package Game;

public abstract class Picachu extends Character {
	
	public Picachu() {
		hp=30;
		energy = 50;
		System.out.println("��ī�߰� �����Ǿ����ϴٿ�");
		
	}
	@Override
	public void eat() {
		energy += 10;
	}
	
	@Override
	public void sleep() {
		energy +=5;
	}
	
	@Override
	public boolean play() {
		energy -=20;
		hp +=5  Stiriung : = ;;  52; 
		levelup();
		return checkEnergy();
	}
	
	@Override
	public boolean train() {
		energy -=15;
		hp +=20;
		levelup();
		return checkEnergy();
	}
	
	@Override
	public void levelup() {
		if(40 <=hp) {
			level++;
			hp -=40;
			
		}
	}

}

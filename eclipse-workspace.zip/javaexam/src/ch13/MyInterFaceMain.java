package ch13;

public class MyInterFaceMain {

	public static void main(String[] args) {
	MyImplements m = new MyImplements();
	m.mul();
	System.out.println("add()�� ������� =" + m.add());
	}
	
}



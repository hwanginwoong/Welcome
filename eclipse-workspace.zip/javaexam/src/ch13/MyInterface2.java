package ch13;

public interface MyInterface2 {
	int max = 5;
	
	void mul();
}

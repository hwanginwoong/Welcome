package ch13;

public class MyImplements implements MyInterface1, MyInterface2 {

	@Override
	   public void mul() {
	      int i, result = 1;
	      for (i = 2; i < max; i++) {
	         result *= i;
	      }

	      System.out.println("mul()�� ������� = " + result);
	   }

	   @Override
	   public int add() {
	      int i, sum = 0;
	      for (i = 0; i < size; i++) {
	         sum += i ;
	      }
	      return sum;
	   }

	}
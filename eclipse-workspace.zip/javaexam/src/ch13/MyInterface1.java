package ch13;

public interface MyInterface1 {	
	int size = 10;
	
	int add();

}

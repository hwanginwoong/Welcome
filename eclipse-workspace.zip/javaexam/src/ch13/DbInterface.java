package ch13;

public interface DbInterface {
	void connect();
	
	void select();
	
	void insert();
	
	
	void update();
	
	void delete();
	

}

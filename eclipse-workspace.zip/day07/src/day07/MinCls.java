package day07;

public class MinCls {
		public static void main(String[]args) {

}
}